from django.urls import path, include
from .views import index, add, get,edit_news, delete_news

urlpatterns = [
    path('', index, name="view_news"),
    path('add/', add, name="add"),
    path('<int:id>/', get, name='get'),
    path('edit/<str:topic>/', edit_news, name='edit_news'),
    path('delete/<str:topic>/', delete_news, name='delete_news'),
]
